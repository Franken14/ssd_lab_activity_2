Q1 
The script asks you to enter the location of the text file, and afterwards prints the middle line

Q2
The scipts prints the names that belong to the user
