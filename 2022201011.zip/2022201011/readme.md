Q1 
Give a command line arguement as an location, and afterwards the script prints the middle line

Q2
The scipts prints the names that belong to the user
