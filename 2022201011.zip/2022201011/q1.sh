#?/bin/bash
echo "enter file location"
read location
a=$(cat $location | wc -l)
let b=($a/2)
awk -v var="$b" 'NR==var {print $0}' $location 

